//
//  YDemoSDK.h
//  YDemoSDK
//
//  Created by BruceYao on 2016/10/18.
//  Copyright © 2016年 BruceYao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomIOSAlertView.h"
@interface YDemoSDK : NSObject

@end
