//
//  AppDelegate.h
//  YDemo1
//
//  Created by BruceYao on 2016/10/18.
//  Copyright © 2016年 BruceYao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

